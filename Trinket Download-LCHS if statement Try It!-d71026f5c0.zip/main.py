# Collecting initial input
engine_indicator_light = input('Engine indicator light: ')

space_suits_on = input('Space suits on? [True/False]: ') == 'True'

shuttle_cabin_ready = input('Shuttle cabin ready? [True/False]: ') == 'True'

crew_status = space_suits_on and shuttle_cabin_ready

computer_status_code = int(input('Computer status code: '))

# Checking engine status
if engine_indicator_light == "green":
    print("Engines started")
elif engine_indicator_light == "green blinking":
    print("Engines preparing to start")
else:
    print("Engines off")

# Part B: Cabin Safety Checks

# Prompt user for spacecraft speed and convert input to float
spacecraft_speed = float(input('Enter the speed of the spacecraft: '))

# Checking crew status
if crew_status:
    print("Crew Ready")
else:
    print("Crew Not Ready")

# Checking computer status
if computer_status_code == 200:
    print("Please stand by. Computer is rebooting.")
elif computer_status_code == 400:
    print("Success! Computer online.")
else:
    print("ALERT: Computer offline!")

# Checking spacecraft speed
if spacecraft_speed > 17500:
    print("ALERT: Escape velocity reached!")
elif spacecraft_speed < 8000:
    print("ALERT: Cannot maintain orbit!")
else:
    print("Stable speed")

# Part C: Fuel Safety Checks

# Collecting additional input for fuel and engine temperature
fuel_level = int(input('Fuel level: '))
engine_temperature = int(input('Engine temperature: '))

# Checking fuel and engine status
if fuel_level > 20000 and engine_temperature <= 2500:
    print("Full tank. Engines good.")
elif fuel_level > 10000 and engine_temperature <= 2500:
    print("Fuel level above 50%. Engines good.")
elif fuel_level > 5000 and engine_temperature <= 2500:
    print("Fuel level above 25%. Engines good.")
elif fuel_level <= 5000 or engine_temperature > 2500:
    print("ALERT: Check fuel level and engine temperature.")
elif fuel_level < 1000 or engine_temperature > 3500 or engine_indicator_light == "red blinking":
    print("ENGINE FAILURE IMMINENT!")
else:
    print("Fuel and engine status pending...")

# Final Bit of Fun: Launch Check

# Define command override
command_override = input('Command override [True/False]: ') == 'True'

# Check if the shuttle can launch
if (fuel_level > 20000 and engine_indicator_light != "red blinking") or command_override:
    print("Cleared to launch!")
else:
    print("Launch scrubbed!")
